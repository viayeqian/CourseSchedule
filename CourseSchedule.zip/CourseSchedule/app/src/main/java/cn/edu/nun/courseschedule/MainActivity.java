package cn.edu.nun.courseschedule;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;

    protected TextView empty;
    protected TextView monColum;
    protected TextView tueColum;
    protected TextView wedColum;
    protected TextView thrusColum;
    protected TextView friColum;
    protected TextView satColum;
    protected TextView sunColum;
    protected RelativeLayout course_table_layout;
    protected int screenWidth;
    protected int aveWidth;

    private AddCourseDialog addCourseDialog;
    private DelCourseDialog delCourseDialog;

    private DatabaseHelper databaseHelper = new DatabaseHelper(this, "database.db", null, 1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDrawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navView = findViewById(R.id.nav_view);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }
        navView.setCheckedItem(R.id.ic_add);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.ic_add:
                        addCourse();
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.ic_del:
                        delCourse();
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.ic_task:
                        Toast.makeText(MainActivity.this, "You clicked Task", Toast.LENGTH_SHORT).show();
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.ic_activity:
                        Toast.makeText(MainActivity.this, "You clicked Activity", Toast.LENGTH_SHORT).show();
                        mDrawerLayout.closeDrawers();
                        break;
                    case R.id.ic_set:
                        Toast.makeText(MainActivity.this, "You clicked Set", Toast.LENGTH_SHORT).show();
                        mDrawerLayout.closeDrawers();
                        break;
                    default:
                }
                return true;
            }
        });

        FloatingActionButton fab = findViewById(R.id.share);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "You clicked Share", Toast.LENGTH_SHORT).show();
            }
        });

        empty = (TextView) this.findViewById(R.id.test_empty);
        monColum = (TextView) this.findViewById(R.id.test_monday_course);
        tueColum = (TextView) this.findViewById(R.id.test_tuesday_course);
        wedColum = (TextView) this.findViewById(R.id.test_wednesday_course);
        thrusColum = (TextView) this.findViewById(R.id.test_thursday_course);
        friColum = (TextView) this.findViewById(R.id.test_friday_course);
        satColum  = (TextView) this.findViewById(R.id.test_saturday_course);
        sunColum = (TextView) this.findViewById(R.id.test_sunday_course);
        course_table_layout = (RelativeLayout) this.findViewById(R.id.test_course_rl);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int aveWidth = width / 8;
        empty.setWidth(aveWidth * 3/4);
        monColum.setWidth(aveWidth * 33/32 + 1);
        tueColum.setWidth(aveWidth * 33/32 + 1);
        wedColum.setWidth(aveWidth * 33/32 + 1);
        thrusColum.setWidth(aveWidth * 33/32 + 1);
        friColum.setWidth(aveWidth * 33/32 + 1);
        satColum.setWidth(aveWidth * 33/32 + 1);
        sunColum.setWidth(aveWidth * 33/32 + 1);
        this.screenWidth = width;
        this.aveWidth = aveWidth;
        int height = dm.heightPixels;
        int gridHeight = height / 12;
        for(int i = 1; i <= 12; i ++){
            for(int j = 1; j <= 8; j ++){
                TextView tx = new TextView(MainActivity.this);
                tx.setId((i - 1) * 8  + j);
                if(j < 8)
                    tx.setBackgroundResource(R.drawable.course_text_view_bg);
                else
                    tx.setBackgroundResource(R.drawable.course_table_last_colum);
                RelativeLayout.LayoutParams rp = new RelativeLayout.LayoutParams(aveWidth * 33 / 32 + 1, gridHeight);
                tx.setGravity(Gravity.CENTER);
                tx.setTextAppearance(R.style.courseTableText);
                if(j == 1) {
                    tx.setText(String.valueOf(i));
                    rp.width = aveWidth * 3/4;
                    if(i == 1)
                        rp.addRule(RelativeLayout.BELOW, empty.getId());
                    else
                        rp.addRule(RelativeLayout.BELOW, (i - 1) * 8);
                } else {
                    rp.addRule(RelativeLayout.RIGHT_OF, (i - 1) * 8  + j - 1);
                    rp.addRule(RelativeLayout.ALIGN_TOP, (i - 1) * 8  + j - 1);
                    tx.setText("");
                }
                tx.setLayoutParams(rp);
                course_table_layout.addView(tx);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.refresh:
                loadCourseData();
                break;
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                break;
            default:
        }
        return true;
    }

    private void addCourse(){
        if(addCourseDialog == null){
            addCourseDialog = new AddCourseDialog(MainActivity.this);
        }
        addCourseDialog.show();
        addCourseDialog.setTvTitleAdd("添加课程");
        addCourseDialog.getLayoutCourseNameAdd().setVisibility(View.VISIBLE);
        addCourseDialog.getLayoutWeekAdd().setVisibility(View.VISIBLE);
        addCourseDialog.getLayoutCourseTimeAdd().setVisibility(View.VISIBLE);
        addCourseDialog.getLayoutTeacherAdd().setVisibility(View.VISIBLE);
        addCourseDialog.getLayoutRoomAdd().setVisibility(View.VISIBLE);
        addCourseDialog.setBtnSureAdd(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseNameAdd = addCourseDialog.getEdCourseNameAdd().getText().toString();
                String teacherAdd = addCourseDialog.getEdTeacherNameAdd().getText().toString();
                String classRoomAdd = addCourseDialog.getEdCourseRoomAdd().getText().toString();
                String dayAdd = addCourseDialog.getEdWeekAdd().getText().toString();
                String timeAdd = addCourseDialog.getEdCourseTimeAdd().getText().toString();
                if (TextUtils.isEmpty(courseNameAdd) || TextUtils.isEmpty(dayAdd) || TextUtils.isEmpty(timeAdd)) {
                    Toast.makeText(MainActivity.this, "基本课程信息未填写", Toast.LENGTH_SHORT).show();
                } else {
                    CourseMode course = new CourseMode(courseNameAdd, teacherAdd, classRoomAdd,
                            Integer.valueOf(dayAdd), Integer.valueOf(timeAdd));
                    if(saveData(course)){
                        Toast.makeText(MainActivity.this,"添加课程成功",Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(MainActivity.this,"添加课程失败",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private boolean saveData(CourseMode course) {
        SQLiteDatabase sqLiteDatabase =  databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("course_name", course.getCourseName());
        values.put("teacher", course.getTeacher());
        values.put("class_room", course.getClassRoom());
        values.put("day", course.getDay());
        values.put("time", course.getTime());
        long rowid = sqLiteDatabase.insert("course", null, values);
        if(rowid != -1){
            return true;
        }else {
            return false;
        }
    }

    private void loadCourseData() {
        SQLiteDatabase sqLiteDatabase =  databaseHelper.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from course", null);
        if (cursor.moveToFirst()) {
            do {
                CourseMode course = new CourseMode(
                        cursor.getString(cursor.getColumnIndex("course_name")),
                        cursor.getString(cursor.getColumnIndex("teacher")),
                        cursor.getString(cursor.getColumnIndex("class_room")),
                        cursor.getInt(cursor.getColumnIndex("day")),
                        cursor.getInt(cursor.getColumnIndex("time")));
                course.setId( cursor.getInt(cursor.getColumnIndex("id")));
                createCourseInfoView(course);
            } while(cursor.moveToNext());
        }
        cursor.close();
    }

    private void createCourseInfoView(final CourseMode course) {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int height = dm.heightPixels;
        int gridHeight = height / 12;
        int[] background = {R.drawable.course_info_blue, R.drawable.course_info_green, R.drawable.course_info_red, R.drawable.course_info_yellow, R.drawable.course_info_light_grey};
        TextView courseInfo = new TextView(this);
        courseInfo.setText(course.getCourseName() + "\n" + course.getTeacher() + "\n" + course.getClassRoom());
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(aveWidth * 31 / 32, (gridHeight - 5) * 2 );
        rlp.topMargin = 5 + (course.getTime()-1) * gridHeight;
        rlp.leftMargin = 1;
        rlp.addRule(RelativeLayout.RIGHT_OF, course.getDay());
        courseInfo.setGravity(Gravity.CENTER);
        Random random = new Random();
        int index = random.nextInt(5);
        switch (index){
            case 0: courseInfo.setBackgroundResource(background[0]); break;
            case 1: courseInfo.setBackgroundResource(background[1]); break;
            case 2: courseInfo.setBackgroundResource(background[2]); break;
            case 3: courseInfo.setBackgroundResource(background[3]); break;
            case 4: courseInfo.setBackgroundResource(background[4]); break;
        }
        courseInfo.setTextSize(12);
        courseInfo.setLayoutParams(rlp);
        courseInfo.setTextColor(Color.WHITE);
        courseInfo.getBackground().setAlpha(222);
        course_table_layout.addView(courseInfo);
    }

    private void delCourse() {
        if(delCourseDialog == null){
            delCourseDialog = new DelCourseDialog(MainActivity.this);
        }
        delCourseDialog.show();
        delCourseDialog.setTvTitleDel("删除课程");
        delCourseDialog.getLayoutCourseNameDel().setVisibility(View.VISIBLE);
        delCourseDialog.setBtnSureDel(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseNameDel = delCourseDialog.getEdCourseNameDel().getText().toString();
                SQLiteDatabase sqLiteDatabase =  databaseHelper.getWritableDatabase();
                sqLiteDatabase.execSQL("delete from course where course_name = ?", new String[] {courseNameDel});
                Toast.makeText(MainActivity.this,"删除课程成功",Toast.LENGTH_SHORT).show();
            }
        });
    }

}