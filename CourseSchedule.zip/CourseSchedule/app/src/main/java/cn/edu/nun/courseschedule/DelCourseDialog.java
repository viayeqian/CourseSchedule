package cn.edu.nun.courseschedule;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Objects;

public class DelCourseDialog extends Dialog {

    private EditText edCourseNameDel;
    private Button btnOkDel, btnCancelDel;
    private LinearLayout layoutCourseNameDel;
    private TextView tvTitleDel;

    public DelCourseDialog(@NonNull Context context) {
        super(context, R.style.dialog_add_course);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_del_course);

        WindowManager m = Objects.requireNonNull(getWindow()).getWindowManager();
        Display d = m.getDefaultDisplay();
        final WindowManager.LayoutParams p = getWindow().getAttributes();
        p.height = (int) (d.getHeight() * 0.7);
        p.width = (int) (d.getWidth() * 0.7);
        getWindow().setAttributes(p);

        setCanceledOnTouchOutside(false);
        edCourseNameDel = (EditText) findViewById(R.id.ed_course_name_del);
        btnOkDel = (Button) findViewById(R.id.btn_ok_del);
        btnCancelDel = (Button) findViewById(R.id.btn_cancel_del);
        layoutCourseNameDel = (LinearLayout) findViewById(R.id.layout_course_name_del);
        tvTitleDel = (TextView) findViewById(R.id.tv_title_del);

        btnCancelDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public void setTvTitleDel(String title) {
        this.tvTitleDel.setText(title);
    }

    public void setBtnSureDel(View.OnClickListener listener) {
        btnOkDel.setOnClickListener(listener);
    }

    public void setBtnCancelDel(View.OnClickListener listener) {
        btnCancelDel.setOnClickListener(listener);
    }

    public EditText getEdCourseNameDel() {
        return edCourseNameDel;
    }

    public LinearLayout getLayoutCourseNameDel() {
        return layoutCourseNameDel;
    }

}