package cn.edu.nun.courseschedule;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Objects;

public class AddCourseDialog extends Dialog {

    private EditText edCourseNameAdd,edWeekAdd, edCourseTimeAdd,edTeacherNameAdd, edCourseRoomAdd;
    private Button btnOkAdd, btnCancelAdd;
    private LinearLayout layoutCourseNameAdd, layoutWeekAdd, layoutCourseTimeAdd, layoutTeacherAdd, layoutRoomAdd;
    private TextView tvTitleAdd;

    public AddCourseDialog(@NonNull Context context) {
        super(context, R.style.dialog_add_course);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_add_course);

        // 将对话框的大小按屏幕大小的百分比设置
        WindowManager m = Objects.requireNonNull(getWindow()).getWindowManager();
        Display d = m.getDefaultDisplay();
        final WindowManager.LayoutParams p = getWindow().getAttributes();
        p.height = (int) (d.getHeight() * 0.7);
        p.width = (int) (d.getWidth() * 0.7);
        getWindow().setAttributes(p);

        setCanceledOnTouchOutside(false);
        edCourseNameAdd = (EditText) findViewById(R.id.ed_course_name_add);
        edWeekAdd = (EditText) findViewById(R.id.ed_week_add);
        edCourseTimeAdd = (EditText) findViewById(R.id.ed_course_time_add);
        edTeacherNameAdd = (EditText) findViewById(R.id.ed_teacher_name_add);
        edCourseRoomAdd = (EditText) findViewById(R.id.ed_course_room_add);
        btnOkAdd = (Button) findViewById(R.id.btn_ok_add);
        btnCancelAdd = (Button) findViewById(R.id.btn_cancel_add);
        layoutCourseNameAdd = (LinearLayout) findViewById(R.id.layout_course_name_add);
        layoutWeekAdd = (LinearLayout) findViewById(R.id.layout_week_add);
        layoutCourseTimeAdd = (LinearLayout) findViewById(R.id.layout_time_add);
        layoutTeacherAdd = (LinearLayout) findViewById(R.id.layout_teacher_add);
        layoutRoomAdd = (LinearLayout) findViewById(R.id.layout_room_add);
        tvTitleAdd = (TextView) findViewById(R.id.tv_title_add);

        btnCancelAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public void setTvTitleAdd(String title) {
        this.tvTitleAdd.setText(title);
    }

    public void setBtnSureAdd(View.OnClickListener listener) {
        btnOkAdd.setOnClickListener(listener);
    }

    public void setBtnCancelAdd(View.OnClickListener listener) {
        btnCancelAdd.setOnClickListener(listener);
    }

    public EditText getEdCourseNameAdd() {
        return edCourseNameAdd;
    }

    public EditText getEdWeekAdd() {
        return edWeekAdd;
    }

    public EditText getEdCourseTimeAdd() {
        return edCourseTimeAdd;
    }

    public EditText getEdTeacherNameAdd() {
        return edTeacherNameAdd;
    }

    public EditText getEdCourseRoomAdd() {
        return edCourseRoomAdd;
    }

    public LinearLayout getLayoutCourseNameAdd() {
        return layoutCourseNameAdd;
    }

    public LinearLayout getLayoutWeekAdd() {
        return layoutWeekAdd;
    }

    public LinearLayout getLayoutCourseTimeAdd() {
        return layoutCourseTimeAdd;
    }

    public LinearLayout getLayoutTeacherAdd() {
        return layoutTeacherAdd;
    }

    public LinearLayout getLayoutRoomAdd() {
        return layoutRoomAdd;
    }

}
